import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:wifi_iot/wifi_iot.dart';



class PairDevice extends StatefulWidget {
  const PairDevice({super.key, required this.title});
  final String title;

  @override
  State<PairDevice> createState() => _PairDeviceState();
}

class _PairDeviceState extends State<PairDevice> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? qrController;
  String connectionStatus = 'Not connected';
  String ssid = '';
  String password = '';

  void _onQRViewCreated(QRViewController controller) {
    qrController = controller;
    controller.scannedDataStream.listen((scanData) async {
      final qrContent = scanData.code ?? '';
      final wifiDetails = _parseWiFiDetails(qrContent);
      if (wifiDetails != null) {
        setState(() {
          ssid = wifiDetails['ssid']!;
          password = wifiDetails['password']!;
        });
        await _connectToWiFi(wifiDetails['ssid']!, wifiDetails['password']!);
        qrController?.dispose();  // Stop scanning once credentials are found.
      } else {
        setState(() {
          connectionStatus = 'Invalid QR Code format';
        });
      }
    });
  }

  Map<String, String>? _parseWiFiDetails(String qrContent) {
    final regex = RegExp(r'SSID:(.*?);PASSWORD:(.*?);');
    final match = regex.firstMatch(qrContent);
    if (match != null) {
      return {'ssid': match.group(1)!, 'password': match.group(2)!};
    }
    return null;
  }

  Future<void> _connectToWiFi(String ssid, String password) async {
    try {
      final isConnected = await WiFiForIoTPlugin.connect(ssid,
          password: password,
          security: NetworkSecurity.WPA,
          joinOnce: true);
      setState(() {
        connectionStatus =
            isConnected ? 'Connected to $ssid' : 'Failed to connect';
      });
    } catch (e) {
      setState(() {
        connectionStatus = 'Error: ${e.toString()}';
      });
    }
  }

  void _reset() {
    setState(() {
      ssid = '';
      password = '';
      connectionStatus = 'Not connected';
    });
  }

  @override
  void dispose() {
    qrController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: SingleChildScrollView( // Make the entire body scrollable
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(20),
              child: ElevatedButton(
                onPressed: () {
                  // Start scanning when the button is pressed
                  setState(() {
                    connectionStatus = 'Scanning...';
                  });
                },
                child: const Text('Scan QR Code'),
              ),
            ),
            Container(
              height: 400, // Set the height of the QR scanner view
              padding: EdgeInsets.all(10),
              child: QRView(
                key: qrKey,
                onQRViewCreated: _onQRViewCreated,
              ),
            ),
            SizedBox(height: 20),
            Text(
              'SSID: $ssid',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            Text(
              'Password: $password',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            SizedBox(height: 20),
            Text(
              connectionStatus,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    if (ssid.isNotEmpty && password.isNotEmpty) {
                      await _connectToWiFi(ssid, password);
                    } else {
                      setState(() {
                        connectionStatus = 'Please scan a QR code first';
                      });
                    }
                  },
                  child: const Text('Connect to WiFi'),
                ),
                SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _reset,
                  child: const Text('Reset'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
