import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:wifi_iot/wifi_iot.dart';
import 'package:http/http.dart' as http;
import 'firebase_service.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'dart:convert';

class WiFiConnectScreen extends StatefulWidget {
  const WiFiConnectScreen({super.key});

  @override
  _WiFiConnectScreenState createState() => _WiFiConnectScreenState();
}

class _WiFiConnectScreenState extends State<WiFiConnectScreen> {
  bool _isConnected = false;
  String _macAddress = "";
  final FirebaseService _firebaseService = FirebaseService();
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? _qrController;
  String _ssid = "";
  String _password = "";
  String connectionStatus = 'Not connected';

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  // Check and request permissions
  Future<void> _checkPermissions() async {
    bool cameraGranted = await _requestCameraPermission();
    if (!cameraGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Camera permission denied. Cannot scan QR code.")),
      );
    }
  }

  Future<bool> _requestCameraPermission() async {
    var status = await Permission.camera.status;
    if (status.isDenied) {
      status = await Permission.camera.request();
    }
    return status.isGranted;
  }

  // Start QR Scanner
  void _startQRScanner() {
    if (_qrController != null) {
      _qrController?.resumeCamera();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Scanning for QR Code...")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("QR Scanner not initialized.")),
      );
    }
  }

  // QR Code Scanner setup
  void _onQRViewCreated(QRViewController controller) {
    _qrController = controller;
    _qrController?.resumeCamera();
    _qrController?.scannedDataStream.listen((scanData) {
      final qrData = scanData.code;
      if (qrData != null) {
        _parseQRCode(qrData);
        _qrController?.pauseCamera();
      }
    });
  }

  // Parse QR Code Data
  void _parseQRCode(String qrData) {
    try {
      final data = jsonDecode(qrData);
      _ssid = data['ssid'] ?? "";
      _password = data['password'] ?? "";

      if (_ssid.isNotEmpty && _password.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Wi-Fi Credentials Scanned: SSID=$_ssid")),
        );
        _connectToWiFi(_ssid, _password);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Invalid QR Code Data")),
        );
      }
    } catch (e) {
      print("Error parsing QR code: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to parse QR code")),
      );
    }
  }

  // Connect to Wi-Fi
  Future<void> _connectToWiFi(String ssid, String password) async {
    try {
      bool isConnected = await WiFiForIoTPlugin.connect(
        ssid,
        password: password,
        joinOnce: true,
        security: NetworkSecurity.WPA,
      );

      if (isConnected) {
        setState(() {
          _isConnected = true;
          connectionStatus = 'Connected to $ssid';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Connected to Wi-Fi: $ssid")),
        );
        _fetchMacAddress();
      } else {
        setState(() {
          connectionStatus = 'Failed to connect';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to connect to Wi-Fi.")),
        );
      }
    } catch (e) {
      print("Error connecting to Wi-Fi: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Connection error: $e")),
      );
    }
  }

  // Fetch MAC Address
  Future<void> _fetchMacAddress() async {
    try {
      final response = await http.get(Uri.parse("http://192.168.4.1/mac"));

      if (response.statusCode == 200) {
        setState(() {
          _macAddress = response.body.trim();
        });
        await _firebaseService.storeDeviceData(_macAddress, _ssid, "ESP32 Device");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Device paired successfully! MAC: $_macAddress")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to fetch MAC address.")),
        );
      }
    } catch (e) {
      print("Error fetching MAC address: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("MAC address fetch error: $e")),
      );
    }
  }

  @override
  void dispose() {
    _qrController?.stopCamera();
    _qrController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pair Device")),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              "Click the button below to scan the QR code on your device.",
              style: TextStyle(fontSize: 16),
            ),
          ),
          ElevatedButton(
            onPressed: _startQRScanner,
            child: const Text("Start QR Scanner"),
          ),
          Expanded(
            child: QRView(
              key: qrKey,
              onQRViewCreated: _onQRViewCreated,
              overlay: QrScannerOverlayShape(
                borderColor: Colors.blueAccent,
                borderRadius: 10,
                borderLength: 30,
                borderWidth: 10,
                cutOutSize: 250,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
